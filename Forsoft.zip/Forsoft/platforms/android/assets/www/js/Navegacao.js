  
  					function hospital(){
				location.href="Hospital.html"
			}
			  		function index(){
				location.href="index.html"
			}
			  		function eventos(){
				location.href="Eventos.html"
			}
			  		function banheiro(){
				location.href="Banheiro.html"
			}
			  		function delegacia(){
				location.href="Delegacia.html"
			}
			  		function food(){
				location.href="Restaurantes.html"
			}
			  		function sleep(){
				location.href="Hotel.html"
			}
			  		function turismo(){
				location.href="PontoTuristicos.html"
			}
			  		function praia(){
				location.href="Praia.html"
			}
			function hospitalF(){
				location.href="gm/hospitalF.html"
			}
			function caminho(x){
				location.href="gm/"+x+".html"
			}
		
		